"use strict";
const https = require('https');
var paytm_config = require("./paytm_config").paytm_config;
var PaytmChecksum = require("paytmchecksum");
var querystring = require("querystring");
var url = require("url");
function route(request, response) {
  console.log("here 1");
  if (request.method == "POST") {
    console.log("here 2");
    // console.log(request)
    var q = url.parse(request.url, true).query;
    console.log(q);

    var paytmParams = {};

    paytmParams.body = {
      requestType: "Payment",
      mid: paytm_config.MID,
      websiteName: paytm_config.WEBSITE,
      orderId: q.ORDER_ID,
      callbackUrl: "https://securegw.paytm.in/theia/paytmCallback?ORDER_ID="+q.ORDER_ID, // Production
      txnAmount: {
        value: q.TXN_AMOUNT,
        currency: "INR"
      },
      userInfo: {
        custId: q.CUST_ID
      }
    };

    // var paramarray = {};
    // paramarray["MID"] = paytm_config.MID; //Provided by Paytm
    // paramarray["ORDER_ID"] = q.ORDER_ID; //unique OrderId for every request
    // paramarray["CUST_ID"] = q.CUST_ID; // unique customer identifier
    // paramarray["INDUSTRY_TYPE_ID"] = paytm_config.INDUSTRY_TYPE_ID; //Provided by Paytm
    // paramarray["CHANNEL_ID"] = paytm_config.CHANNEL_ID; //Provided by Paytm
    // paramarray["TXN_AMOUNT"] = q.TXN_AMOUNT; // transaction amount
    // paramarray["WEBSITE"] = paytm_config.WEBSITE; //Provided by Paytm
    // paramarray["CALLBACK_URL"] =
    //   "https://pguat.paytm.com/paytmchecksum/paytmCallback.jsp"; //Provided by Paytm
    // //paramarray['MOBILE_NO'] = q.MOBILE_NO; // customer 10 digit mobile no.
    // console.log(paramarray);
    // paytm_checksum.genchecksum(paramarray, paytm_config.MERCHANT_KEY, function(
    //   err,
    //   checksum
    // ) {
    //   console.log("Checksum: ", checksum, "\n");
    //   response.writeHead(200, {
    //     "Content-type": "text/json",
    //     "Cache-Control": "no-cache"
    //   });
    //   response.write(JSON.stringify(checksum));
    //   response.end();
    // });

    PaytmChecksum.generateSignature(
      JSON.stringify(paytmParams.body),
      paytm_config.MERCHANT_KEY
    ).then(function(checksum) {
      paytmParams.head = {
        signature: checksum
      };

      var post_data = JSON.stringify(paytmParams);
      console.log(post_data)

      var options = {
        /* for Staging */
        //hostname: "securegw-stage.paytm.in",

        /* for Production */
         hostname: 'securegw.paytm.in',

        port: 443,
        path:
          "/theia/api/v1/initiateTransaction?mid="+paytm_config.MID+"&orderId="+q.ORDER_ID,
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Content-Length": post_data.length
        }
      };

      var responseData = "";
      var post_req = https.request(options, function(post_res) {
        post_res.on("data", function(chunk) {
          responseData += chunk;
        });

        post_res.on("end", function() {
          console.log("Response: ", responseData);
          response.writeHead(200, {
         "Content-type": "text/json",
          "Cache-Control": "no-cache"
         });
        //response.write(JSON.stringify(responseData));
        response.write(responseData);

        response.end();
        });
      });

      post_req.write(post_data);
      post_req.end();
      
      // response.writeHead(200, {
      //    "Content-type": "text/json",
      //     "Cache-Control": "no-cache"
      //    });
      //   response.write(JSON.stringify(responseData));
      //   response.end();
    });
  } else {
    response.writeHead(200, { "Content-type": "text/json" });
    response.end();
  }
}

/*
 * Generate checksum by parameters we have in body
 * Find your Merchant Key in your Paytm Dashboard at https://dashboard.paytm.com/next/apikeys
 */

function htmlEscape(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}
exports.route = route;
