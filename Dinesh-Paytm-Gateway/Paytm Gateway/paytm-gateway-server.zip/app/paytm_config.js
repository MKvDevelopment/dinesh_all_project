module.exports = {
  // Production
	// paytm_config: {
	// 	MID: 'MONEYS58179742213320',
	// 	WEBSITE: 'DEFAULT',
	// CHANNEL_ID: 'WAP',
	// INDUSTRY_TYPE_ID: 'Retail',
	// MERCHANT_KEY : 'hl8NxahKDo57F4UK'
	// }
  
  // Production 2
	paytm_config: {
		MID: 'Dinesh18399201056005',
		WEBSITE: 'DEFAULT',
	CHANNEL_ID: 'WAP',
	INDUSTRY_TYPE_ID: 'Retail',
	MERCHANT_KEY : '65f0OZx!pvZn!3NL'
	}
  
  // Staging
	// paytm_config: {
	// 	MID: 'Earnin63309349157038',
	// 	WEBSITE: 'WEBSTAGING',
	// CHANNEL_ID: 'WAP',
	// INDUSTRY_TYPE_ID: 'Retail',
	// MERCHANT_KEY : 'oBxqB&6ZgdlGOyTt'
	// }
}